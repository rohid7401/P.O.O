
public interface Switch {

	public abstract void on();
	public abstract void off();	
	
}