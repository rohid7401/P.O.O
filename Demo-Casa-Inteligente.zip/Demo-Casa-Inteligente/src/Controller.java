import java.util.ArrayList;

public class Controller extends ArrayList<Device>{

	
}
